package com.sevein.zoo;

public class App {
    public static void main(String [] args) {
        System.out.println("\n Welcome to my Zoo! \n");
        Animal myNewAnimal = new Animal();
        System.out.println("\n Animal arrival date is " + myNewAnimal.getAnimalArrivalDate());

        Animal anotherAnimal = new Animal("female", 10, 223, "Athena", "fla10", "10/12/15", "Brown and Tan", "Africa", "10/9/25");

        System.out.println("\n Sex is: " + anotherAnimal.getSex());
        System.out.println("\n Age is: " + anotherAnimal.getAge());
        System.out.println("\n Weight is: " + anotherAnimal.getWeight());
        System.out.println("\n Name is: " + anotherAnimal.getAnimalName());
        System.out.println("\n ID is: " + anotherAnimal.getAnimalID());
        System.out.println("\n Birthday is: " + anotherAnimal.getAnimalBirthDate());
        System.out.println("\n Color is: " + anotherAnimal.getAnimalColor());
        System.out.println("\n Origin is: " + anotherAnimal.getAnimalOrigin());
        System.out.println("\n Arrival Date is: " + anotherAnimal.getAnimalArrivalDate());

        //Create a new lion
        Lion myLion = new Lion();

        // output the arrival date of my new lion
        System.out.println("\n My new lion arrived: " + myLion.getAnimalArrivalDate());

        // How many lions do we have?(Should be 1)
        System.out.println("\n Number of lions: " + Lion.getNumOfLions());

        // How many animals do we have? (should be 3)
        System.out.println("\n Number of Animals: " + Animal.getNumOfAnimals());

    }

}


