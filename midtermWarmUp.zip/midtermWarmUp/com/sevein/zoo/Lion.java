package com.sevein.zoo;

//super class is Animal
public class Lion extends Animal{

    //Static field to track number of lions created
    private static int numOfLions = 0;

    //Default constructor
    public Lion() {
        //uses the super constructor to create an object (Animal)
        super();
        numOfLions++;
    }
    // Use the full Animal Constructor
    public Lion(String sex, int age, int weight, String animalName, String animalID, String animalBirthDate, String animalColor, String animalOrigin, String animalArrivalDate) {

        super(sex, age, weight, animalName, animalID, animalBirthDate, animalColor, animalOrigin, animalArrivalDate);
        numOfLions++;

    }
    //Static getter for number of lions
    public static int getNumOfLions() {return numOfLions;}
}
